package com.example.onboarder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnboarderApplicationTests {

	@Test
	void contextLoads() {
	}

}
